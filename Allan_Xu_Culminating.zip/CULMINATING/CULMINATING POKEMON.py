'''
Author: Allan Xu
Date: June 7, 2016
Course: ICS 3UP - 01
Teacher: Mr. Hutchison
School: Woburn Collegiate Institute

LOW LEVEL EXPLAINATIONS (OPTIONAL, CREATED TO MAKE MARKING/PLAYER EASIER IN THE CASE OF POTIENTIAL CONFUSION)

Description: 
"A turn based game in which your objective is to knock out both of your opponents Pok�mon. Player battle with one
Pok�mon currently battling and the other one waiting. Pok�mon each have four attacks
and the three stats of health, attack, and speed. A Pok�mon is knocked out when its health is completely depleted, Pok�mon
are unable to battle when knocked out, and victory is achieved when both of your opponent�s Pok�mon are knocked out. Both
the player and the AI both select one attack per turn, with the faster Pok�mon�s attack landing first, depleting the
other�s health. The higher a Pok�mon�s health, the more attacks they can endure. The higher a Pok�mon�s attack stat, the
more damage their attacks will do. The higher a Pok�mon�s speed stat, the sooner they will attack. The player may also
choose to switch to his other Pok�mon, if it is not knocked out, instead of attacking, during his/her turn."

Flow:
This code implements what is described in the preface through the following process:
 - Randomly select two Pokemon for the Ai, remove those Pokemon from the possible selections 
 - Ask user which two Pokemon they would like to use and select those for the user
 - Play the game music 
 - Play game (repetive process which continues until winner is determined, containing the following steps):
       - Ask user if they would like to attack or switch
       - Animate and process switch if chosen
       - Ask which attack if chosen (Occurs after faster Pokemon's attack if the Ai's Pokemon is faster)
       - Animate and process faster Pokemon's attack
       - Animate and process slower Pokemon's attack, if no switch occured
       - Check if Pokemon are knocked out, replace them and inform user if so
       - Check if a winner is determined
- Announce winner

Pokemon + Game related words (incase misunderstanding happends in docstrings):
AI: The computer which selects attacks, it is completley random and has no intelligence, lacked a better word.
Player: The user, or the side which the user makes decisions for.
Process an attack: Decrement or increment any stats based on the effects of the attack.
Attacking Pokemon: The Pokemon which is currently using the attack. 
Opposing Pokemon: The Pokemon which is not currently using the attack (being attacked).
Delay: Wait time after a certain task is completed
Sufficient data in the lists: Both player and Ai lists contain valid Pokemon that are capable of battling (not knocked out)
***The Pokemon are stored in the following format within a list
   [name, attack #1, attack #2, attack #3, attack #4, current health, maximum possible health, attack, speed]
***In the examples in the docstring, explainations of what would have occured, replaced what actually occured very
frequently due to animations and long processing being very hard to demonstrate through comment
*** It is completley normal for a player to attack twice in a row if they just had one of thier Pokemon knocked out
'''
import pygame as pg
import easygui as eg
import random as r

#Initializing the program and importing images
pg.init()
screen = pg.display.set_mode([640, 360]) 
Background = pg.image.load("Background.jpg").convert()   
Blackout = pg.image.load ("Black.png").convert()
Whiteout = pg.image.load ("White.png").convert()
Water = pg.image.load("Water.png").convert()
Fish = pg.image.load("Fish.png").convert_alpha()
Ring = pg.image.load("Ring.png").convert_alpha()
Time_ = pg.image.load("Time.png").convert()
Fire = pg.image.load("Fire.png").convert_alpha()
Dragon = pg.image.load("Dragon.png").convert_alpha()
Skull = pg.image.load("Skull.png").convert_alpha()
Cannonball = pg.image.load("Canon.png").convert_alpha()
Space = pg.image.load("Space.png").convert()
Comet = pg.image.load("Comet.png").convert_alpha()
Arceus = pg.image.load("Arceus.png").convert_alpha()
Darkrai = pg.image.load("Darkrai.png").convert_alpha()
Dialga = pg.image.load("Dialga.png").convert_alpha()
Palkia = pg.image.load("Palkia.png").convert_alpha()
Giratina = pg.image.load("Giratina.png").convert_alpha()

def draw_screen(player, ai, duration):
    ''' (list, list, int) -> N/A
    Draws and flips the screen used while player decisions are being made, then the program waits for the specified number of miliseconds before proceeding. No return value.
    >>> draw_screen (player, ai, 100)
    #Screen drawn and flipped based on contents of player and ai followed by a 100 milisecond delay
    pre: All images used are already imported
    post: Screen is created and flipped
    '''        
    screen.blit(Background, [0, 0])
    if player[0][0] == 'Arceus': screen.blit (Arceus, [175, 165])
    elif player[0][0] == 'Darkrai': screen.blit (Darkrai, [175, 165])
    elif player[0][0] == 'Dialga': screen.blit(Dialga, [175, 145])
    elif player[0][0] == 'Palkia': screen.blit(Palkia, [175, 145])
    elif player[0][0]== 'Giratina': screen.blit (Giratina, [175, 150])
    if ai[0][0] == 'Arceus': screen.blit (Arceus, [375, 165])      
    elif ai[0][0] == 'Darkrai': screen.blit (Darkrai, [375, 165])
    elif ai[0][0] == 'Dialga': screen.blit(Dialga, [375, 145])
    elif ai[0][0] == 'Palkia': screen.blit(Palkia, [375, 145])
    elif ai[0][0] == 'Giratina': screen.blit (Giratina, [375, 150])
    f = pg.font.Font(None, 36)
    player_hp = f.render(player[0][0] + ' ' + str(player[0][5]) + ' / ' + str(player[0][6]), 1, (0, 0, 0), (255, 255, 255))
    ai_hp = f.render(ai[0][0] + ' ' + str(ai[0][5]) + ' / ' + str(ai[0][6]), 1, (0, 0, 0), (255, 255, 255))
    if (player[0][5] > 0):screen.blit (player_hp, (125, 300))
    if (ai[0][5] > 0): screen.blit (ai_hp, (375, 300))
    pg.display.flip()
    pg.time.wait(duration)
    

def spacial_rend (side, player, ai):
    ''' (int, list, list) -> N/A
    Processes and animates the attack special rend which halves the opposing Pokemon's remaining health. The side the attacking Pokemon is battling for is represented by the first int passed to the function (2 for ai and 1 for player). No return value.
    >>> spacial_rend (2, player, ai)
    #Animation for spacial rend and player's pokemon would lose half its remaining health
    pre: All images used are already imported, player and ai contain sufficient data regarding the pokemon
    post: Attack animated and processed
    '''        
    if (side == 2):
        player[0][5] = player[0][5]/2
    else:
        ai[0][5] = ai[0][5]/2
    for i in range (180):
        screen.blit(Space, [0, 0])
        screen.blit(Comet, [4*i, i])
        pg.display.flip()
        pg.time.wait(20)

def roar_of_time (side, player, ai):
    ''' (int, list, list) -> N/A
    Processes and animates the attack roar of time which double the attacking Pokemon's health up to its original maximum health. The side the attacking Pokemon is battling for is represented by the first int passed to the function (2 for ai and 1 for player). No return value.
    >>> roar_of_time (1, player, ai)
    #Animation for roar of time and player's pokemon would have its health doubled or restored to maximum if it has more than half its health remaining
    pre: All images used are already imported, player and ai contain sufficient data regarding the pokemon
    post: Attack animated and processed
    '''    
    for i in range(6):
        screen.blit(Time_, [0, 0])
        pg.display.flip()
        pg.time.wait(250)
        draw_screen(player, ai, 250)     
    if (side == 1):
        player[0][5] = min (player[0][5]*2, player[0][6])
    else:
        ai[0][5] = min (ai[0][5]*2, ai[0][6])
    
def shadow_force (side, player, ai):
    ''' (int, list, list) -> N/A
    Processes and animates the attack shadow force which shares the sum of the health of both Pokemon on the field evenly (rounded up). The side the attacking Pokemon is battling for is represented by the first int passed to the function (2 for ai and 1 for player). No return value.
    >>> shadow_force (1, player, ai)
    Animation for shadow force and both pokemon would have their health evenly split, capping at their maximum possible health
    pre: All images used are already imported, player and ai contain sufficient data regarding the pokemon
    post: Attack animated and processed
    '''        
    for i in range(6):
        screen.blit(Background, [0, 0])
        pg.display.flip()
        pg.time.wait(250)
        draw_screen(player, ai, 250)
    val = (player[0][5] + ai[0][5])/2 + 1
    player[0][5] = min (val, player[0][6])
    ai[0][5] = min (val, ai[0][6])    
    
def night_spear (side, player, ai):
    ''' (int, list, list) -> N/A
    Processes and animates the attack night spear which deals damage to the opposing Pokemon equal to the attacking Pokemon's attack stat * 1.2. The side the attacking Pokemon is battling for is represented by the first int passed to the function (2 for ai and 1 for player). No return value.
    >>> night_spear (2, player, ai)
    Animation for night spear and player's pokemon would have their health decreased by a number equivilant to the attacking Pokemon's attack stat * 1.2
    pre: All images used are already imported, player and ai contain sufficient data regarding the pokemon
    post: Attack animated and processed
    '''          
    if (side == 2):
        for i in range (350, 175, -3):
            draw_screen(player, ai, 0)
            screen.blit(Skull, [i, 150])
            pg.display.flip()
            pg.time.wait(20)        
        player[0][5] = player[0][5] - (ai[0][7] * 120 / 100)
    else:
        for i in range (200, 375, 3):
            draw_screen(player, ai, 0)
            screen.blit(Skull, [i, 150])
            pg.display.flip()
            pg.time.wait(20)        
        ai[0][5] = ai[0][5] - (player[0][7] * 120 / 100)  
    
def dragon_pulse (side, player, ai):
    ''' (int, list, list) -> N/A
    Processes and animates the attack dragon pulse which deals damage to the opposing Pokemon equal to the attacking Pokemon's attack stat * 0.8. The side the attacking Pokemon is battling for is represented by the first int passed to the function (2 for ai and 1 for player). No return value.
    >>> dragon_pulse(2, player, ai)
    Animation for dragon pulse and player's pokemon would have their health decreased by a number equivilant to the attacking Pokemon's attack stat * 0.8
    pre: All images used are already imported, player and ai contain sufficient data regarding the pokemon
    post: Attack animated and processed
    '''      
    if (side == 2):
        for i in range (350, 175, -3):
            draw_screen(player, ai, 0)
            screen.blit(Dragon, [i, 150])
            pg.display.flip()
            pg.time.wait(20)
        player[0][5] = player[0][5] - (ai[0][7] * 80 / 100)
    else:
        for i in range (200, 375, 3):
            draw_screen(player, ai, 0)
            screen.blit(Dragon, [i, 150])
            pg.display.flip()
            pg.time.wait(20)
        ai[0][5] = ai[0][5] - (player[0][7] * 80 / 100)
    
def dark_pulse (side, player, ai):
    ''' (int, list, list) -> N/A
    Processes and animates the attack dark pulse which deals damage to the opposing Pokemon equal to the attacking Pokemon's attack stat * 0.8. The side the attacking Pokemon is battling for is represented by the first int passed to the function (2 for ai and 1 for player). No return value.
    >>> dark_pulse(2, player, ai)
    Animation for dark pulse and player's pokemon would have their health decreased by a number equivilant to the attacking Pokemon's attack stat * 0.8
    pre: All images used are already imported, player and ai contain sufficient data regarding the pokemon
    post: Attack animated and processed
    '''          
    x_intervals = []
    y_intervals = []
    for i in range (1, 37):
        y_intervals.append(i * 10)
    for i in range (1, 65):
        x_intervals.append(i*10)
    for lim in range (2, 64):
        for i in range (1, lim):
            for j in range (1, 36):
                screen.blit(Ring, [x_intervals[i], y_intervals[j]])
        pg.display.flip()
        pg.time.wait(20)       
    if (side == 2):
        player[0][5] = player[0][5] - (ai[0][7] * 80 / 100)
    else:
        ai[0][5] = ai[0][5] - (player[0][7] * 80 / 100)  
    
def ominous_wind (side, player, ai):
    ''' (int, list, list) -> N/A
    Processes and animates the attack ominous wind which deals damage to the opposing Pokemon equal to the attacking Pokemon's attack stat * 0.6 and increases the attacking Pokemon's attack stat by 50. The side the attacking Pokemon is battling for is represented by the first int passed to the function (2 for ai and 1 for player). No return value.
    >>> ominous_wind(2, player, ai)
    Animation for ominous wind and player's pokemon would have their health decreased by a number equivilant to the attacking Pokemon's attack stat * 0.6, while Ai's Pokemon's attack stat would increase by 50
    pre: All images used are already imported, player and ai contain sufficient data regarding the pokemon
    post: Attack animated and processed
    '''          
    for i in range(6):
        screen.blit(Blackout, [0, 0])
        pg.display.flip()
        pg.time.wait(250)
        draw_screen(player, ai, 250)    
    if (side == 2):
        player[0][5] = player[0][5] - (ai[0][7] * 60 / 100)
        ai[0][7] = ai[0][7] + 50
    else:
        ai[0][5] = ai[0][5] - (player[0][7] * 60 / 100)
        player[0][7] = player[0][7] + 50
          
def flamethrower(side, player, ai):
    ''' (int, list, list) -> N/A
    Processes and animates the attack flamethrower which decreases the opposing Pokemon's health by 250. The side the attacking Pokemon is battling for is represented by the first int passed to the function (2 for ai and 1 for player). No return value.
    >>> flash_canon(2, player, ai)
    Animation for flamethrower and player's pokemon would have their health decreased by 250
    pre: All images used are already imported, player and ai contain sufficient data regarding the pokemon
    post: Attack animated and processed
    '''           
    if (side == 2):
        for i in range (350, 175, -3):
            draw_screen(player, ai, 0)
            screen.blit(Fire, [i, 150])
            pg.display.flip()
            pg.time.wait(20)        
        player[0][5] = player[0][5] - 250
    else:
        for i in range (200, 375, 3):
            draw_screen(player, ai, 0)
            screen.blit(Fire, [i, 150])
            pg.display.flip()
            pg.time.wait(20)        
        ai[0][5] = ai[0][5] - 250
  
def water_pulse(side, player, ai):   
    ''' (int, list, list) -> N/A
    Processes and animates the attack water pulse which deals damage to the opposing Pokemon equal to the attacking Pokemon's attack stat * 0.6 and increases the attacking Pokemon's attack stat by 50. The side the attacking Pokemon is battling for is represented by the first int passed to the function (2 for ai and 1 for player). No return value.
    >>> water_pulse(2, player, ai)
    Animation for water pulse and player's pokemon would have their health decreased by a number equivilant to the attacking Pokemon's attack stat * 0.6, while Ai's Pokemon's attack stat would increase by 50
    pre: All images used are already imported, player and ai contain sufficient data regarding the pokemon
    post: Attack animated and processed
    '''         
    for i in range (183):
        screen.blit(Water, [0, 0])
        screen.blit(Fish, [640- 4*i, 150])
        pg.display.flip()
        pg.time.wait(20)      
    if (side == 2):
        player[0][5] = player[0][5] - (ai[0][7] * 60 / 100)
        ai[0][7] = ai[0][7] + 50
    else:
        ai[0][5] = ai[0][5] - (player[0][7] * 60 / 100)
        player[0][7] = player[0][7] + 50
        
def flash_canon (side, player, ai):
    ''' (int, list, list) -> N/A
    Processes and animates the attack flash canon which deals damage to the opposing Pokemon equal to the attacking Pokemon's attack stat * 0.6 and increases the attacking Pokemon's attack stat by 50. The side the attacking Pokemon is battling for is represented by the first int passed to the function (2 for ai and 1 for player). No return value.
    >>> flash_canon(2, player, ai)
    Animation for flash canon and player's pokemon would have their health decreased by a number equivilant to the attacking Pokemon's attack stat * 0.6, while Ai's Pokemon's attack stat would increase by 50
    pre: All images used are already imported, player and ai contain sufficient data regarding the pokemon
    post: Attack animated and processed
    '''       
    for i in range (180):
        screen.blit(Whiteout, [0, 0])
        screen.blit(Cannonball, [4*i, 150])
        pg.display.flip()
        pg.time.wait(20)    
    if (side == 2):
        player[0][5] = player[0][5] - (ai[0][7] * 60 / 100)
        ai[0][7] = ai[0][7] + 50
    else:
        ai[0][5] = ai[0][5] - (player[0][7] * 60 / 100)
        player[0][7] = player[0][7] + 50
       
def switch_pokemon (player):
    ''' (list) -> N/A
    Given a list of 2 Pokemon, switch the order of them. Since the battling Pokemon is always the first Pokemon in the list, this changes the Pokemon which is currently battling.
    >>> switch_pokemon(player)
    Pokemon switched
    pre: All images used are already imported, player and ai contain sufficient data regarding the pokemon
    post: Pokemon switched
    '''        
    tmp = player[0]
    player[0] = player[1]
    player[1] = tmp
    
def select_attack(name, side, player, ai):
    ''' (string, int, list, list) -> N/A
    Given the name of an attack, call the function responsible for animating and processing that attack while passing on important parameters (attacking side, and both player's pokemon). After the attack check some crucial in game elements and animate them if necessary. Elements include if any Pokemon were knocked out, and if either player has no more remaining Pokemon. 
    >>> select_attack(Flamethrower, 2, player, ai)
    Calls the function for flamethrower passing on 2, player and ai to it 
    pre: All attack functions are properly created
    post: Attack function called
    '''           
    if name == 'Spacial Rend': spacial_rend(side, player, ai)
    elif name == 'Roar of Time': roar_of_time(side, player, ai)
    elif name == 'Shadow Force': shadow_force(side, player, ai)
    elif name == 'Night Spear': night_spear(side, player, ai)        
    elif name == 'Dragon Pulse': dragon_pulse(side, player, ai) 
    elif name == 'Dark Pulse': dark_pulse(side, player, ai)         
    elif name == 'Ominous Wind': ominous_wind(side, player, ai)   
    elif name == 'Flamethrower': flamethrower(side, player, ai)  
    elif name == 'Water Pulse': water_pulse(side, player, ai) 
    elif name == 'Flash Canon': flash_canon(side, player, ai)
    draw_screen(player, ai, 1500)    
    if side == 1:
        message = (str(player[0][0]) + str(' used ')+ str(name) + str('!'))
    else:
        message = (str(ai[0][0]) + str(' used ') + str(name) + str('!'))
    eg.msgbox(msg = message, title = 'ATTACK', ok_button = "GOT IT!")
    if player[0][5] <= 0:
        eg.msgbox(msg = player[0][0] + ' was knocked out!', title = 'KNOCKED OUT', ok_button = "GOT IT!")
        player[0][0] = '1'
        draw_screen(player, ai, 1500)
        player.pop(0)    
    if ai[0][5] <= 0:
        eg.msgbox(msg = ai[0][0] + ' was knocked out!', title = 'KNOCKED OUT', ok_button = "GOT IT!")
        ai[0][0] = '1'
        draw_screen(player, ai, 1500)
        ai.pop(0)    
    if len(ai) == 0:
        eg.msgbox(msg = 'CONGRADULATIONS, YOU WON!', title = 'WINNER', ok_button = "I'M AWESOME!")
        quit()
    if len (player) == 0:
        eg.msgbox(msg = 'SORRY, YOU LOST!', title = 'LOSER', ok_button = "I'M BAD!")
        quit()
    
def ai_pokemon (pokemon, pokemons, ai):
    ''' (list, list, list) -> list, list, list
    Selects Pokemon for the Ai team at random then deletes those Pokemon from the possible selection list. First and second parameters are the possible selection lists, with the first containing just the Pokemon name while the second contains the full info, third parameter is the list which contains information about the Ai's selected Pokemon
    >>> ai_pokemon ([pokemon 1, pokemon 2, pokemon 3, pokemon 4, pokemon 5], [pokemon 1, pokemon 2, pokemon 3, pokemon 4, pokemon 5], [])
    [pokemon 1, pokemon 3, pokemon 4], [pokemon 1, pokemon 3, pokemon 4], [pokemon 2, pokemon 5]
    pre: The selection list is properly filled
    post: Ai Pokemon selected
    '''               
    ra = r.randint(0, 4)
    ai[0] = pokemons[ra]
    pokemons.pop(ra)
    pokemon.pop(ra)
    ra = r.randint(0, 3)
    ai[1] = pokemons[ra]  
    pokemons.pop(ra)
    pokemon.pop(ra)    
    
def player_pokemon(pokemon, pokemons, player):
    ''' (list, list, list) -> list, list, list
    Gets user input about the Pokemon he/she wishes to select, then deletes those Pokemon from the possible selection list. First and second parameters are the possible selection lists, with the first containing just the Pokemon name while the second contains the full info, third parameter is the list which contains information about the Ai's selected Pokemon
    >>> ai_pokemon ([pokemon 1, pokemon 2, pokemon 3], [pokemon 1, pokemon 2, pokemon 3], [])
    [pokemon 2], [pokemon 2], [pokemon 1, pokemon 3]
    pre: The selection list is properly filled
    post: Player Pokemon selected
    '''                   
    choice = eg.choicebox (msg = ("Select your first Pokemon"), title = ("Pokemon Selection"), choices = (pokemon))
    for i in range (0, 3):
        if (choice == pokemons[i][0]):
            player[0] = pokemons[i]
            pos = i
    pokemons.pop(pos)
    pokemon.pop(pos)
    choice = eg.choicebox (msg = ("Select your second Pokemon"), title = ("Pokemon Selection"), choices = (pokemon))
    for i in range (0, 2):
        if (choice == pokemons[i][0]):
            player[1] = pokemons[i]  
            pos = i
    pokemons.pop(pos)
    pokemon.pop(pos)    
def battle_music():
    '''
    (N/A) -> NA
    Plays the battle music in an infinite loop
    >>>battle_music()
    Music plays
    pre: Music file downloaded
    Music plays
    '''
    pg.mixer.init()
    pg.mixer.music.load("Pokemon_Music.mp3")
    pg.mixer.music.play(-1)    
    
def play_game(ai, player):
    ''' (list, list) -> N/A
    Gets user input about the game decisions they would like to make them calls the appropriate functions to handle these decisions based on various factors. 
    >>> player_game(ai, player)
    Game Starts
    pre: All functions properly created
    post: Game Begins
    '''           
    while (True):    
        draw_screen(player, ai, 1500)
        options = ['Attack', 'Switch']
        if len(player) < 2: #Eliminates user option of switching Pokemon if he/she no longer has a Pokemon to switch into
            options.pop(1)
        choice = eg.choicebox (msg = ("Would you like to attack or switch Pokemon?"), title = ("Player Decision"), choices = options)
        if (choice == 'Switch'): #If user is swtiching Pokemon (decided by speed)
            switch_pokemon (player)
            choice = (ai[0][r.randint(1, 4)])
            draw_screen(player, ai, 1500)
            select_attack(choice, 2, player, ai)
            draw_screen(player, ai, 1500)
        else:
            if (ai[0][8] <= player[0][8]): #If user is attacking first (decided by speed)
                choice = eg.choicebox (msg = ("What attack would you like to use?"), title = ("Choosing Attack"), choices = (player[0][1:5]))
                select_attack(choice, 1, player, ai)
                draw_screen(player, ai, 1500)
                choice = (ai[0][r.randint(1, 4)])
                select_attack(choice, 2, player, ai)   
                draw_screen(player, ai, 1500)
            else: #If Ai is attacking first
                choice = (ai[0][r.randint(1, 4)])
                select_attack(choice, 2, player, ai)
                draw_screen(player, ai, 1500)
                choice = eg.choicebox (msg = ("What attack would you like to use?"), title = ("Choosing Attack"), choices = (player[0][1:5]))
                select_attack(choice, 1, player, ai)
                draw_screen(player, ai, 1500)    

def main():
    pokemon = ['Giratina','Dialga','Palkia','Darkrai','Arceus'] #List of Pokemon Names
    pokemons = [['Giratina', 'Dragon Pulse', 'Shadow Force', 'Ominous Wind', 'Flamethrower', 400, 400, 250, 300],
    ['Dialga', 'Dragon Pulse', 'Roar of Time', 'Flash Canon', 'Flamethrower', 900, 900, 150, 100],
    ['Palkia', 'Dragon Pulse', 'Spacial Rend', 'Water Pulse', 'Flamethrower', 600, 600, 200, 230],
    ['Darkrai', 'Night Spear', 'Shadow Force', 'Dark Pulse', 'Ominous Wind', 350, 350, 300, 300],
    ['Arceus', 'Spacial Rend', 'Shadow Force', 'Roar of Time', 'Night Spear', 500, 500, 300, 250]]
    #List of all Pokemon with their stats
    ai = [1, 2]
    player = [1, 2]    
    ai_pokemon(pokemon, pokemons, ai)
    player_pokemon(pokemon, pokemons, player)
    eg.msgbox(msg = "Let the Battle Begin!", title = 'POKEMON', ok_button = "START")
    screen = pg.display.set_mode([640, 360])    
    pg.display.set_caption("POKEMON BATTLE")
    battle_music()
    play_game(ai, player)
main() 